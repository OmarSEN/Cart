import React from 'react';

import '../assets/style/app.css';
import ProductList from "./product/product-list.jsx";
import ShoppingCart from "./cart/shopping-cart.jsx";
import products from "../data/products";


/*
 define root component
*/
export default class App extends React.Component {
    constructor(props) {
        super(props);

        this.state = { products : [], cart: [], filteredProducts: [] };
        this.addProductToCart = this.addProductToCart.bind(this);
        this.deleteProductFromCart = this.deleteProductFromCart.bind(this);
        this.handleCartQuantityChange = this.handleCartQuantityChange.bind(this);
        this.handleFilterInputChange = this.handleFilterInputChange.bind(this);
    }
    componentDidMount() {
        setTimeout(  () => this.setState( { products : products, filteredProducts: products }), 10);
    }

    addProductToCart = (product) => {
        let currentCart = this.state.cart;

        const productAlreadyExists = currentCart.filter(p => p.id === product.id);
        if (productAlreadyExists.length > 0){ // Already exists
            productAlreadyExists[0].quantity++;
            this.setState({ cart: currentCart });
        } else {
            const { id, weight, name, image, price } = product;

            const productToAdd = { id, weight, name, image, price };
            productToAdd.quantity = 1;
            this.setState({ cart: [...currentCart, productToAdd] });
        }

    }

    deleteProductFromCart = (productId) => {
        const currentCart = this.state.cart;

        const newCart = currentCart.filter(product => product.id !== productId);

        this.setState({cart: newCart});
    }

    handleCartQuantityChange = (event, productId) => {
        const newValue = event.target.value;
        if (newValue <= 0){
            this.deleteProductFromCart(productId);
            return;
        }
        const currentCart = this.state.cart;

        const productAlreadyExists = currentCart.filter(p => p.id === productId);
        if (productAlreadyExists.length > 0){
            productAlreadyExists[0].quantity = newValue;
            this.setState({ cart: currentCart });
        }
    }

    handleFilterInputChange = (event) => {
        const filter = event.target.value;
        const products = this.state.products;

        const filteredProducts = products.filter(p => p.name.toLowerCase().includes(filter.toLowerCase()));
        this.setState({filteredProducts})
    }


    render() {
    return(
            <div className="app">
                <ProductList products={this.state.filteredProducts}
                             addProductToCart={this.addProductToCart}
                             handleFilterInputChange={this.handleFilterInputChange}/>
                <ShoppingCart cartProducts={this.state.cart}
                              deleteProductFromCart={this.deleteProductFromCart}
                              handleCartQuantityChange={this.handleCartQuantityChange}/>
            </div>
    );
  }

}
