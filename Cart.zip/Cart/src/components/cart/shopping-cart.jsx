import React from "react";
import CartProduct from "./cart-product.jsx";
import "../../assets/style/cart.css";

export default class ShoppingCart extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        const totalSum = this.props.cartProducts.reduce((accum, val) => {
            return accum + val.price * val.quantity;
        }, 0);
        const totalWeight = this.props.cartProducts.reduce((accum, val) => {
            return accum + val.weight * val.quantity;
        }, 0);

        return (
            <div className="cart">
                <h4>Panier</h4>
                {this.props.cartProducts.length > 0 && <span className="weight">{`Poids total: ${totalWeight}`}</span>}

                {this.props.cartProducts.map(cartProduct => {
                    return <CartProduct key={cartProduct.id}
                                        product={cartProduct}
                                        deleteProductFromCart={this.props.deleteProductFromCart}
                                        handleCartQuantityChange={this.props.handleCartQuantityChange} />;
                })}

                <div className="total">
                    <span>{`total commande: ${totalSum}`}</span>
                </div>
            </div>
        )
    }

}