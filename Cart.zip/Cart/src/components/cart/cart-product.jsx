import React from "react";
import deleteProductFromCart from "../../assets/images/poubelle.jpg";

export default class CartProduct extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        const {product} = this.props;
        const imageSrc = require(`../../${product.image}`).default;

        return (

            <div className="product">
                <div className="info">
                    <span className="name">{product.name}</span><br/>
                </div>
                <div className="imageProduit">
                    <img src={imageSrc} alt="Product image"/>
                </div>
                <input type="number" value={product.quantity} onChange={(event) => this.props.handleCartQuantityChange(event, product.id)}></input>
                <img src={deleteProductFromCart} className="button" alt="Delete product from cart" onClick={() => this.props.deleteProductFromCart(product.id)}></img>
            </div>
        )
    }

}