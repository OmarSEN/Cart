import React from 'react';
import "../../assets/style/product.css"
import addToCartImage from "../../assets/images/panier.jpg"


export default class Product extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {

        const {product} = this.props;
        const imageSrc = require(`../../${product.image}`).default;

        return (
            <div className="product">
                <div className="info">
                    <span className="name">{product.name}</span><br/>
                    <span className="description">{product.description}</span>
                    <span className="weight">{product.weight}</span>
                </div>
                <div className="imageProduit">
                    <img src={imageSrc} alt="Product image"/>
                </div>
                <p className="stock">{`qté ${product.stock}`}</p>
                <span className="price">{product.price}</span>
                <img src={addToCartImage} className="button" alt="Add product to cart" onClick={() => this.props.addProductToCart(product)}></img>
            </div>
        )
    }

}