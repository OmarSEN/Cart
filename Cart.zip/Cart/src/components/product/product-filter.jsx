import React from "react";

export default class ProductFilter extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {

        return (
            <input className='filter' placeholder='filtrer les produits' onChange={this.props.handleFilterInputChange}></input>
        )
    }

}