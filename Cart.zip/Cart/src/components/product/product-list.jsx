import React from "react";
import ProductFilter from "./product-filter.jsx";
import "../../assets/style/productList.css"
import Product from "./product.jsx";

export default class ProductList extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (
            <div className='productList'>
                <h4>Boutique</h4>
                <ProductFilter handleFilterInputChange={this.props.handleFilterInputChange}/>
                {this.props.products.map(product => {
                    return <Product key={product.id} product={product} addProductToCart={this.props.addProductToCart}/>;
                })}

            </div>
        )
    }

}